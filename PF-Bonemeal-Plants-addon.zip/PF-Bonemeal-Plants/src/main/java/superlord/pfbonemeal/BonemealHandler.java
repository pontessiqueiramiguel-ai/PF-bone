package superlord.pfbonemeal;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.level.BonemealEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Makes Prehistoric Fauna plants that are not bonemealable drop an item when bonemeal is used on them
 * (same behaviour as vanilla sunflowers). Tall plants drop their short version.
 *
 * Works only with registry ids, so it does not depend on the original mod's classes
 * and keeps working with modified versions of it.
 */
@Mod.EventBusSubscriber(modid = PFBonemealAddon.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class BonemealHandler {
	private static final String PF = "prehistoricfauna";

	/** block id -> item that is dropped */
	private static final Map<ResourceLocation, ResourceLocation> DROPS = new HashMap<>();

	private static void put(String block, String item) {
		DROPS.put(new ResourceLocation(PF, block), new ResourceLocation(PF, item));
	}

	static {
		// Tall plants drop the short version
		put("tall_horsetail", "horsetail");
		put("tall_osmunda", "osmunda");
		put("tall_osmundacaulis", "osmundacaulis");
		put("tall_otozamites", "otozamites");
		put("tall_taeniopteris", "taeniopteris");
		put("tall_fiddlehead_fern", "fiddlehead_fern");
		put("tall_archaefructus", "archaefructus");

		// Others drop themselves
		put("dead_osmundacaulis", "dead_osmundacaulis");
		put("callianthus", "callianthus");
		put("azolla", "azolla");
		put("cobbania", "cobbania");
		put("nelumbo", "nelumbo");
		put("quereuxia", "quereuxia");
		put("algae_carpet", "algae_carpet");
		put("stoneworts", "stoneworts");
		put("moss_carpet", "moss_carpet");
		put("ptilophyllum_base", "ptilophyllum_base");
	}

	@SubscribeEvent
	public static void onBonemeal(BonemealEvent event) {
		ResourceLocation blockId = ForgeRegistries.BLOCKS.getKey(event.getBlock().getBlock());
		ResourceLocation itemId = DROPS.get(blockId);
		if (itemId == null || !ForgeRegistries.ITEMS.containsKey(itemId)) {
			return;
		}

		Level level = event.getLevel();
		if (!level.isClientSide) {
			Item item = ForgeRegistries.ITEMS.getValue(itemId);
			Block.popResource(level, event.getPos(), new ItemStack(item));
		}
		// ALLOW = bonemeal counts as used (Forge consumes it and the game plays the particles)
		event.setResult(Event.Result.ALLOW);
	}
}
