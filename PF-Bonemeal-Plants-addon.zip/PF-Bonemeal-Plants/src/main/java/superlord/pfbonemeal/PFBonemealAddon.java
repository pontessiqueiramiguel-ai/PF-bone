package superlord.pfbonemeal;

import net.minecraftforge.fml.common.Mod;

/**
 * Addon for Prehistoric Fauna. All logic lives in {@link BonemealHandler}, which is
 * registered automatically through @Mod.EventBusSubscriber.
 */
@Mod(PFBonemealAddon.MOD_ID)
public class PFBonemealAddon {
	public static final String MOD_ID = "pfbonemeal";

	public PFBonemealAddon() {
	}
}
